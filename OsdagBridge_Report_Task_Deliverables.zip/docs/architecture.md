# architecture.md

Documentation placeholder.
